/*
    group members name       id
    1 kaleb adem            3409/14
	2 surafel laye          2877/14
	3.Tammiru semeneh       2903/14
	4. Wendimagegn abera    3083/14
	5. Bereket asefa        0580/14    
	6.Tsion obsa            2513/13
	 
*/




#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include<cstdlib>
using namespace std;
struct Book
{
    string log;
    string title;
    string author;
    int year;
    bool availability;
};
int choice1, numBooks = 0, choice = 1, choice2, ch, num_order, choice3,cr= 0,result,frist = 0,i;
Book books[30];
string un, pw, user, pass, null,l[2];
string given;
int r[2][53]={{11,12,15,13,10,23,7,31,10,42,
               12,55,20,76,16,93,23,116,9,125,
			   4,130,29,160,15,176,10,187,6,194,18,213,
			   29,242,18,288,33,296,5,302,6,309,
			   4,313,19,334,11,346,60} , 
		   {14,15,15,17,12,30,9,41,
            7,49,12,63,20,84,23,108,30,139,
			19,158,4,327,24,163,34,198,21, 
			221,9,231,7,238,20,260,37,297,40,
			 353,10,364,10,375,7,
			 382,23,406,18}};

void addBook( int &numBooks);
void displayBooks(int numBooks,int m = 0,int n = 1);
void saveBooks( int numBooks);
void loadBooks( int &numBooks);
void isLoggedIn();
void owner_user();
void serach(string given);
void lan(int x,int y,int z = 0,int c =1){
	for( int i=0;i<y;i++){
		result= c*i + x;
		cout<<l[cr].at(result);
	}
	if ( z == 1){
		cout<<endl;
	}
}

class owner
{
    string user;
    string pass;

  public:
    int owner_num;
    void owner_perlog()
    {
        ifstream read;
        read.open("owner.txt", ios::in);
        getline(read, user);
        read >>pass >> owner_num;
        read.close();
    }
    void owner_log(string &ps, string &us)
    {
    	 owner_perlog();
        if (ps == pass && user == us)
        {
            owner_user();
        }
        system("cls");
        choice3;
        cout <<"   "<<"Your input is wrong: try again [  You are not a manager ["<<user<<"] select user[2]]\n";
        isLoggedIn();
    }
    void owner_reg()
    {
        system("cls");
        cout << "\n[Regstration only if you are owner]\n\n";
        cout << "ENTER YOUR FNAME,MNAME AND LNAME  \n:";
        getline(cin >> ws, user);
        cout << "CERATE YOUR OWN PASSWORD (WITHOUT SPACE)\n";
        cin >> pass;

        owner_num++;
        ofstream write;
        write.open("owner.txt", ios::out);
        write << user << endl
              << pass << " "
              << owner_num;
        write.close();
        system("cls");
        cout << "[Welcome " << user << "!"
             << "]" << endl;
        owner_user();
    }
}acss;

int main()
{cout<<"\t\tHU,DAYE CUMPUS:\n";
cout<<"###################################################################################\n";
 cout<<"\t\tLIBRARY MANAGMENT SYSTM:\n";
     numBooks = 0;
    // Load books from file
    loadBooks( numBooks);

	ifstream read;
	read.open("language.txt");
	getline(read, l[0]);
	getline(read, l[1]);
	read.close();
        
        if(cr == 0 && frist == 0){
        a:	
		cout<<"Language option\n"<<"1.English[default][0]\n"<<"2.Affan Oromo[1]\n";
        	cin>>cr;
        	if( cr >1){
        		system("cls");
        		cout<<"Your input is wrong: try agian\n";
        		goto a;
			}
         	system("cls");
        	frist++;
        	main();	
        }
       while(choice){
	   
	 lan(0,0,1,0);lan(0,r[cr][0],1);
	lan(r[cr][1],r[cr][2],1,0);lan(r[cr][3],r[cr][4],1);
	lan(r[cr][5],r[cr][6],1);lan(r[cr][7],r[cr][8],1);
	lan(0,0,1,0); lan(r[cr][9],r[cr][10],1);
    cin >> choice;
    
switch (choice){
case 1:
    	 acss.owner_perlog();
        if (acss.owner_num == 0)
        {
            acss.owner_reg();
        }        

        lan(r[cr][11],r[cr][12],1);lan(0,0,1,0);lan(r[cr][13],r[cr][14],1);
        getline(cin >> ws, user);lan(r[cr][15],r[cr][16],1);cin >> pass;
        system("cls");
         lan(r[cr][17],r[cr][18],0,1);cout<< user;lan(r[cr][19],r[cr][20],1);
            
    if(pass != null && user != null ){
	
    ofstream write;
        write.open("user.txt", ios::app | ios::out);
        write << user << " "
              << pass << endl;
        write.close();
}  
choice = 0;
		 break;
		 case 2:
        isLoggedIn();
        choice=0;
        break;
        case 3:
        	system("cls");
        	goto a;
        	break;
		default:
        	system("cls");
            cout<<"try again\n";
            main();
            break;
        }
   
}

    // menu loop
    do
    {
        if(cr == 0){
        	cout<<" =>Library Management System<=" << endl;
		}
        lan(r[cr][23],r[cr][24],1);lan(r[cr][25],r[cr][26],1);  lan(r[cr][45],r[cr][46],1);
		lan(r[cr][27],r[cr][28],1);
        lan(r[cr][29],r[cr][30],1);
        if( cr == 1){	
		lan(r[cr][31],r[cr][32],1);
    }
        cin >> choice1;    	      	
        switch (choice1)
        {
        case 1:
            displayBooks(numBooks);
            
            break;
        case 2:
             if(cr == 0){
            cout << "ARE YOU SURE {yes[1]/ no[0]}: ";
         
			 }
	
			 else{
			 
            lan(r[cr][33],r[cr][34],1,1);
        }
            cin >> ch;
            if (ch == 1)
            {
                system("cls");
               choice=1;
                main();
            }
            system("cls");
            
            break;
            case 3:
            	serach(given);
            	 break;
         	
        default:
        	system("cls");
             cout<<"Your input is wrong\n";
           break;
        }
    } while (choice1 != 4);
return 0;
}

// Function to add a book to the library

void addBook( int &numBooks)
{
    Book newBook;
    cout << "Enter the catlog of the book: ";
    getline(cin >> ws,newBook.log);
    cout << "Enter the title of the book: ";
    getline(cin>> ws,newBook.title);

    cout << "Enter the author of the book: ";
    getline(cin >> ws,newBook.author);

    cout << "Enter the year of publication: ";
    cin >> newBook.year;

    cout << "Is the book is  available : if{online [1] / offline{0}: ";

    cin >> newBook.availability;

    books[numBooks] = newBook;
    saveBooks(numBooks);
    cout << "Book added successfully." << endl;
}

// Function to display all books in the library
void displayBooks( int numBooks,int m,int n)
{
    if (numBooks == 0)
    {  
	    system("cls");
        cout << "No books in library." << endl;
      
        return;
    }
    system("cls");
	if(n = 1){
    cout << setw(25);lan(r[cr][37],r[cr][38],0);
    cout<< setw(16);lan(r[cr][39],r[cr][40],0);
    cout<< setw(12);lan(r[cr][41],r[cr][42],0);
    cout<<setw(10);lan(r[cr][43],r[cr][44],1);
    n--;
}
    for (int i = m; i < numBooks; i++)
    {
    
          cout << "[catloge]{";
        if (books[i].log != null)
        {
            cout << books[i].log<<"} ";
        }
        else
        {
           cout << "unknown"
                 << "}";
           
        }
        cout << setw(25) << books[i].title << setw(15) << books[i].author << setw(10) << books[i].year << setw(10) << books[i].availability << endl;
    }
}
// Function to save all books to a file
void saveBooks( int numBooks)
{
    ofstream write;
    write.open("books.txt" ,ios::app | ios::out);
        write << books[numBooks].log<<","
              << books[numBooks].title<<","
              << books[numBooks].author <<","
              << books[numBooks].year << ","
              << books[numBooks].availability<<","<<numBooks+1<< endl;
    
    write.close();

    cout << "Books saved to file." << endl;
    system("cls");
}

// Function to load all books from a file

void loadBooks( int &numBooks)
{
	char w[100];
	char *l;
    ifstream read;
	 read.open("books.txt");
           if (!read.is_open())
            {
                cout << "[The  system is no working right now come later][" << user << "] ";
                system("exit");
            }
    while (read.getline(w,100))
    {
     l = strtok(w, ",");
        books[numBooks].log = l;
        
        l = strtok(NULL, ",");
         books[numBooks].title =l;
     
           l = strtok(NULL, ",");
         books[numBooks].author =l;
         
        l = strtok(NULL, ",");
		books[numBooks].year  = atoi(l);
	
        l = strtok(NULL, ",");
        books[numBooks].availability = atoi(l);
		 numBooks++;
    }
    read.close();
}
  
void owner_user(){
    system("cls");
    	numBooks = 0;
    do
    {
    	 loadBooks( numBooks);
        cout << "Library Management System" << endl;
        cout << "1. Add Book" << endl;
        cout << "2. Display Books" << endl;
        cout<<  "3. Modify owner and Passcode"<<endl;
        cout << "4. Log out" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice2;
       
        switch (choice2)
        {
        case 1:
            addBook( numBooks);
            break;
        case 2:
            displayBooks( numBooks);
            break;
        case 3:
          acss.owner_reg();
            break;
        case 4:
            cout << "ARE YOU SURE {yes[1]/ no[0]}:";
            cin.ignore();
            cin >> ch;
            if (ch == 1)
            {
                system("cls");
                main();
            }
            else
            {
                owner_user();
            }
            break;
        case 5:
            cout << "Exiting program..." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
            break;
        }
    } while (choice2 != 4);

    system("exit");
}

void isLoggedIn()
{
    string user, pass;
    string us[10], ps[10];
    owner call;

    cout << "Enter a username: ";
    getline(cin >> ws, user);
    cout << "Enter your {"<<user<<"}Id: ";
    cin >> pass;
    cout << " LOG IN AS {manager [1] OR user[2]}\n";
    cin >> choice3;
    if (choice3 == 2)
    {
        ifstream read;
        read.open("user.txt");
                 if (!read.is_open())
            {
                cout << "The  system is no working right now come later][" << user << "] ";
                system("exit");
            }
             
        while (read.eof() == 0)
        {
           read >> us[i];
            read >> ps[i];
            i++;
        }
        
        read.close();
        for(int m = 0; m < i;m++){
		
        if (us[m] == user && pass == ps[m])
        { 
        	 system("cls");
            cout << "Successfully logged in!" << endl
                 << endl;
            cout << "[Welcome " << user << "!"
                 << "]" << endl;
                 break;
        }      
        else
        {
        	   if(i -1 == m){  
              system("cls");
            cout << endl;
            cout << "Invalid login!" <<i<<m<<endl;
        		i = 0;
				 isLoggedIn();
			}
		
        }
    }
    }
    else if (choice3 == 1)
    {
        call.owner_log(pass, user);
    }
}
void serach(string given){
int no = 0;
 lan(r[cr][47],r[cr][48],1);
              	getline(cin >>ws,given);
        for(i = 0;i<numBooks;i++){
        	if(  books[i].log == given||books[i].title == given|| books[i].author == given || books[i].year == atoi(given.c_str())){
			no++;
        		 displayBooks( i+1,i,1);
			}
		}
		if(no == 0){
			system("cls");
				cout<<"not found\n";
	}	
}
