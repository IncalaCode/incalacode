create database HOTEL_MANAGEMENT_SYSTEM
 
use HOTEL_MANAGEMENT_SYSTEM
drop HOTEL_MANAGEMENT_SYSTEM
DROP TABLE Booking;
CREATE TABLE Booking (
    BookingID          INT NOT NULL PRIMARY KEY,
    BookingType        VARCHAR(20) NOT NULL check (BookingType IN ('online','on_walk')),
    BookingDate        DATE NOT NULL
);
  
CREATE TABLE Employee (
    EmployeeID         INT NOT NULL PRIMARY KEY,
    FirstName          VARCHAR(20) NOT NULL,
    LastName           VARCHAR(20) NOT NULL,
    Gender             VARCHAR(20) CHECK (Gender IN ('Male', 'Female', 'Other')),
    PhoneNumber        INT NOT NULL
);
CREATE TABLE Staff (
    StaffID            INT NOT NULL PRIMARY KEY,
    StaffType          VARCHAR(20) NOT NULL,
);
CREATE TABLE Servicess (
    ServiceID          INT NOT NULL PRIMARY KEY,
    ServiceType        VARCHAR(20) NOT NULL,
    ServiceCost        DECIMAL(7,2) NOT NULL
);
CREATE TABLE EmployeeService (
    EmployeeID         INT NOT NULL,
    ServiceID          INT NOT NULL,
    StaffID            INT NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    FOREIGN KEY (ServiceID) REFERENCES ServiceSS(ServiceID),
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
    PRIMARY KEY (EmployeeID, ServiceID, StaffID)
);

CREATE TABLE Manager (
    ManagerID          INT NOT NULL PRIMARY KEY,
    FirstName          VARCHAR(20)  NOT NULL,
    LastName           VARCHAR (20) NOT NULL,
    StaffID            INT NOT NULL,
    EmployeeID         INT NOT NULL,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);

CREATE TABLE Reservation (
    ReservationID      INT NOT NULL PRIMARY KEY ,
    CheckInDate        DATE NOT NULL,
    CheckOutDate       DATE NOT NULL,
    NoOfDays           INT NOT NULL,
    BookingID          INT NOT NULL,
    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);
 CREATE TABLE Room (
    RoomNo             INT NOT NULL ,
    RoomType           VARCHAR(20) NOT NULL,
    BedType            VARCHAR(20) CHECK (BedType IN ('Single', 'Double', 'Queen', 'King')),
    ReservationID          INT NOT NULL,
    NoOfOccupants      INT NOT NULL CHECK (NoOfOccupants >= 0),
    RoomPrice          DECIMAL(7,2) NOT NULL,
    PRIMARY KEY(RoomNo),
   FOREIGN KEY (ReservationID ) REFERENCES  Reservation(ReservationID )
);
DROP TABLE Customer
CREATE TABLE Customer (
    ReservationID           INT  NOT NULL,
    CustomerID         INT   NOT NULL,
    FirstName          VARCHAR(20)  NOT NULL,
    LastName           VARCHAR(20)  NOT NULL,
    Gender             VARCHAR(7)  CHECK (Gender IN ('Male', 'Female', 'Other')),
    PhoneNumber        INT  NOT NULL,
    PRIMARY KEY(CustomerID,ReservationID ),
   FOREIGN KEY (ReservationID ) REFERENCES  Reservation(ReservationID )
);
CREATE TABLE Address (
    Street             VARCHAR(30)  NOT NULL,
    City               VARCHAR(30)  NOT NULL,
    Country            VARCHAR(20)  NOT NULL,
    ZipCode            INT  NOT NULL CHECK (ZipCode >= 0),
    BookingID          INT  PRIMARY KEY,
    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);
CREATE TABLE Invoice (
InvoiceNo           INT PRIMARY KEY,
BookingID           INT  UNIQUE ,
FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);
CREATE TABLE Connector(
BookingID           INT  ,
StaffID             INT  ,
ServiceUsedNum      INT  ,
FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);
CREATE TABLE Transactions (
TransactionNo       INT  PRIMARY KEY,
PaymentMethod       VARCHAR(20) CHECK (PaymentMethod IN ('Cash', 'Card', 'Online')),
PaymentDate         DATE ,
InvoiceNo           INTEGER ,
BookingID           INT ,
FOREIGN KEY (BookingID) REFERENCES Booking(BookingID),
FOREIGN KEY (InvoiceNo) REFERENCES Invoice
);

-- Insert a booking
INSERT INTO Booking (BookingID, BookingType, BookingDate) VALUES (1, 'Online', '2021-10-01');
INSERT INTO Booking (BookingID, BookingType, BookingDate) VALUES (2, 'on_walk', '2021-10-03');
INSERT INTO Booking (BookingID, BookingType, BookingDate) VALUES (3, 'Online', '2021-10-06');
INSERT INTO Booking (BookingID, BookingType, BookingDate) VALUES (4, 'Online', '2021-10-08');
INSERT INTO Booking (BookingID, BookingType, BookingDate) VALUES (5, 'on_walk', '2021-10-12');
select * from Booking

-- Insert an employee
INSERT INTO Employee (EmployeeID, FirstName, LastName, Gender, PhoneNumber) VALUES (1001, 'caleb', 'adem', 'male', 1234567890);
INSERT INTO Employee (EmployeeID, FirstName, LastName, Gender, PhoneNumber) VALUES (1002, 'SURAFLE', 'LAYE', 'male', 1234567891);
INSERT INTO Employee (EmployeeID, FirstName, LastName, Gender, PhoneNumber) VALUES (1003, 'TAMIRU', 'SEMENCH', 'male', 1234567892);
INSERT INTO Employee (EmployeeID, FirstName, LastName, Gender, PhoneNumber) VALUES (1004, 'WENDIMAGEGN', 'ABERA', 'male', 1234567893);
INSERT INTO Employee (EmployeeID, FirstName, LastName, Gender, PhoneNumber) VALUES (1005, 'ROBERA', 'TESFAYE', 'male', 1234567894);


-- Insert a staff member
INSERT INTO Staff (StaffID, StaffType) VALUES (2001, 'roomkeeping');
INSERT INTO Staff (StaffID, StaffType) VALUES (2002, 'Spaces to Relax');
INSERT INTO Staff (StaffID, StaffType) VALUES (2003, 'meals');
INSERT INTO Staff (StaffID, StaffType) VALUES (2004, 'workout');
INSERT INTO Staff (StaffID, StaffType) VALUES (2005, 'tour');

-- Insert a service
INSERT INTO Servicess(ServiceID, ServiceType, ServiceCost) VALUES (3001, 'Cleaning', 50.00);
iNSERT INTO Servicess(ServiceID, ServiceType, ServiceCost) VALUES (3002, 'bath', 60.00);
iNSERT INTO Servicess(ServiceID, ServiceType, ServiceCost) VALUES (3003, 'breakfast', 20.00);
iNSERT INTO Servicess(ServiceID, ServiceType, ServiceCost) VALUES (3004, 'gym', 40.00);
iNSERT INTO Servicess(ServiceID, ServiceType, ServiceCost) VALUES (3005, 'animals', 10.00);
select * from Servicess

-- Insert an employee-service relation
INSERT INTO EmployeeService (EmployeeID, ServiceID, StaffID) VALUES (1001, 3001, 2001);
INSERT INTO EmployeeService (EmployeeID, ServiceID, StaffID) VALUES (1002, 3002, 2002);
INSERT INTO EmployeeService (EmployeeID, ServiceID, StaffID) VALUES (1003, 3003, 2003);
INSERT INTO EmployeeService (EmployeeID, ServiceID, StaffID) VALUES (1004, 3004, 2004);
INSERT INTO EmployeeService (EmployeeID, ServiceID, StaffID) VALUES (1005, 3005, 2005);


select * from EmployeeService 
-- Insert a manager
INSERT INTO Manager (ManagerID, FirstName, LastName, StaffID, EmployeeID) VALUES (4001, 'caleb', 'adem', 2001, 1001);
INSERT INTO Manager (ManagerID, FirstName, LastName, StaffID, EmployeeID) VALUES (4002, 'BERKET', 'ASSFA', 2002, 1002);
INSERT INTO Manager (ManagerID, FirstName, LastName, StaffID, EmployeeID) VALUES (4003, 'TAMIRU', 'SEMENCH', 2003, 1003);
INSERT INTO Manager (ManagerID, FirstName, LastName, StaffID, EmployeeID) VALUES (4004, 'BIRUK', 'BIRGU', 2004, 1004);
INSERT INTO Manager (ManagerID, FirstName, LastName, StaffID, EmployeeID) VALUES (4005, 'TSION', '0BSA', 2005, 1005);

-- Insert a reservation
INSERT INTO Reservation (ReservationID, CheckInDate, CheckOutDate, NoOfDays, BookingID) VALUES (5001, '2021-10-10', '2021-10-15', 5, 1);
INSERT INTO Reservation (ReservationID, CheckInDate, CheckOutDate, NoOfDays, BookingID) VALUES (5002, '2021-10-10', '2021-10-19', 9, 2);
INSERT INTO Reservation (ReservationID, CheckInDate, CheckOutDate, NoOfDays, BookingID) VALUES (5003, '2021-10-10', '2021-10-12', 2, 3);
INSERT INTO Reservation (ReservationID, CheckInDate, CheckOutDate, NoOfDays, BookingID) VALUES (5004, '2021-10-10', '2021-10-16', 6, 4);
INSERT INTO Reservation (ReservationID, CheckInDate, CheckOutDate, NoOfDays, BookingID) VALUES (5005, '2021-10-10', '2021-10-11', 1, 5);

-- Insert a room
INSERT INTO Room (RoomNo, RoomType, BedType,  ReservationID, NoOfOccupants, RoomPrice) VALUES (6001, 'normal', 'Single',5001, 1, 140.00);
INSERT INTO Room (RoomNo, RoomType, BedType,  ReservationID, NoOfOccupants, RoomPrice) VALUES (6002, 'Deluxe', 'Queen',5002, 2, 180.00);
INSERT INTO Room (RoomNo, RoomType, BedType,  ReservationID, NoOfOccupants, RoomPrice) VALUES (6003, 'Deluxe', 'King',5003, 1, 200.00);
INSERT INTO Room (RoomNo, RoomType, BedType,  ReservationID, NoOfOccupants, RoomPrice) VALUES (6004, 'normal', 'Double',5004, 4, 300.00);
INSERT INTO Room (RoomNo, RoomType, BedType,  ReservationID, NoOfOccupants, RoomPrice) VALUES (6005, 'Deluxe', 'King',5005, 2, 200.00);
select * from Room 

-- Insert a customer
INSERT INTO Customer (ReservationID,CustomerID, FirstName, LastName,Gender,PhoneNumber) VALUES (5001,4001,'CALEB','ADEM','MALE',092341563);
INSERT INTO Customer (ReservationID,CustomerID, FirstName, LastName,Gender,PhoneNumber) VALUES (5002,4002,'BERKET','ASSFA','MALE',092341564);
INSERT INTO Customer (ReservationID,CustomerID, FirstName, LastName,Gender,PhoneNumber) VALUES (5003,4003,'WENDIMAGEGN','ABERA','MALE',092341565);
INSERT INTO Customer (ReservationID,CustomerID, FirstName, LastName,Gender,PhoneNumber) VALUES (5004,4004,'SURAFLE','LAYE','MALE',092341566);
INSERT INTO Customer (ReservationID,CustomerID, FirstName, LastName,Gender,PhoneNumber) VALUES (5005,4005,'TSION','0BSA','Female',092341567);
SELECT * FROM Customer
-- Insert a Address
INSERT INTO Address (Street, City,Country,ZipCode,BookingID ) VALUES('PEASSIA','HAWWASSA','ETHIOPIA',7001,01);

-- Insert a Connector
INSERT INTO Connector(BookingID,StaffID,ServiceUsedNum) VALUES (01,2001,8);
INSERT INTO Connector(BookingID,StaffID,ServiceUsedNum) VALUES (02,2002,23);
INSERT INTO Connector(BookingID,StaffID,ServiceUsedNum) VALUES (03,2003,2);
INSERT INTO Connector(BookingID,StaffID,ServiceUsedNum) VALUES (04,2004,4);
INSERT INTO Connector(BookingID,StaffID,ServiceUsedNum) VALUES (05,2005,7);

 -- Insert a Invoice
INSERT INTO Invoice(InvoiceNo,BookingID ) VALUES(8001,01);
INSERT INTO Invoice(InvoiceNo,BookingID ) VALUES(8002,02);
INSERT INTO Invoice(InvoiceNo,BookingID ) VALUES(8003,03);
INSERT INTO Invoice(InvoiceNo,BookingID ) VALUES(8004,04);
INSERT INTO Invoice(InvoiceNo,BookingID ) VALUES(8005,05);
select * from Invoice
--Insert a Transactions
INSERT INTO Transactions (TransactionNo,PaymentMethod,PaymentDate,InvoiceNo,BookingID) VALUES (9001,'Card','2021-10-10',8001,01);
INSERT INTO Transactions (TransactionNo,PaymentMethod,PaymentDate,InvoiceNo,BookingID) VALUES (9002,'Cash','2021-10-10',8002,02);
INSERT INTO Transactions (TransactionNo,PaymentMethod,PaymentDate,InvoiceNo,BookingID) VALUES (9003,'Online','2021-10-10',8003,03);
INSERT INTO Transactions (TransactionNo,PaymentMethod,PaymentDate,InvoiceNo,BookingID) VALUES (9004,'Online','2021-10-10',8004,04);
INSERT INTO Transactions (TransactionNo,PaymentMethod,PaymentDate,InvoiceNo,BookingID) VALUES (9005,'Cash','2021-10-10',8005,05);

select * from Transactions





---SELECTION   AND, OR, NOT, IN, BETWEEN
SELECT * FROM Employee WHERE Gender = 'MALE';
SELECT * FROM Booking WHERE BookingType = 'Online';
SELECT * FROM Customer WHERE Gender = 'Male' OR PhoneNumber= 092341565;
select * from booking;
SELECT * FROM Employee;


---- PROJECTION
SELECT FirstName, LastName FROM Employee;
SELECT * FROM Booking;
SELECT  ReservationID, DATEDIFF(DAY,CheckInDate ,CheckOutDate ) AS  NoOfDays FROM Reservation;
  

--- INTERSTION 
SELECT EmployeeID,FirstName FROM Employee
INTERSECT
SELECT EmployeeID,FirstName FROM Manager;

 

---union
SELECT EmployeeID,FirstName FROM Employee
UNION
SELECT EmployeeID,FirstName FROM Manager;


-- CARTESIAN
SELECT * FROM Transactions,Invoice;
